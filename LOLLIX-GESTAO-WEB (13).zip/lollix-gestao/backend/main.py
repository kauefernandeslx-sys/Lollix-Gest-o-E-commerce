from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from datetime import date

app = FastAPI(title="LOLLIX GESTÃO API", version="1.0.0", description="API inicial para gestão do e-commerce Lollix")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

@app.get("/")
def health():
    return {"app": "LOLLIX GESTÃO", "status": "online", "environment": "demo"}

@app.get("/api/dashboard")
def dashboard():
    # Valores demonstrativos. Substituir por dados reais após definir a integração e autenticação.
    return {"as_of": str(date.today()), "demo": True, "revenue": 48592.80, "orders": 286, "average_ticket": 169.90, "pending": 12}

@app.get("/api/orders")
def orders():
    return {"demo": True, "items": [
        {"id": "LXL-2841", "customer": "Cliente demonstração 1", "amount": 489.90, "status": "Pagamento aprovado"},
        {"id": "LXL-2840", "customer": "Cliente demonstração 2", "amount": 729.00, "status": "Em separação"}
    ]}
